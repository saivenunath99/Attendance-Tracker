# AttendanceTracker
Attendance Tracker can be used for recording student's attendance using the app.
It has features like viewing student's day wise attendance and cumulative attendance.
